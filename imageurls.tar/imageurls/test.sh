!/bin/sh

/home/ubuntu/DHP/imageurls

for dir in */*/; do
    mkdir -p -- $dir/urls;
done

